const cartList = {
    "products": [
        {
            "name": "ASAPP Pen",
            "quantity": 4,
            "stock": 5
        },
        {
            "name": "ASAPP Stickers",
            "quantity": 10,
            "stock": 4
        }
    ]
}

export default cartList;