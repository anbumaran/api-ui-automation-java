const productList = {
    "products": [
        {
            "name": "ASAPP Pen",
            "description": "State of the art pen, hand-crafted by the internationally famous D. Lacy. We guarantee it will never run out of ink.",
            "stock": 10
        },
        {
            "name": "ASAPP Stickers",
            "description": "Be the envy of your colleagues with these amazing stickers.",
            "stock": 5
        },
        {
            "name": "ASAPP Water Bottle",
            "description": "Ever been thirsty at work? No more, our new state of the art water bottles will keep you hydrated 24/7. Water not included.",
            "stock": 0
        }
    ]
};

export default productList;
