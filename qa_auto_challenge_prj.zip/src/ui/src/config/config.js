const config = {
    "api": "http://localhost:5000"
}

export default config