#!/usr/bin/env bash

sleep 5 && npm start
