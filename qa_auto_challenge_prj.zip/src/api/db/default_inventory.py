default_inventory = [
    {
        "product_name": "ASAPP Pens",
        "product_qty": 50,
        "product_descr": "State of the art pen, "
                         "hand-crafted by the internationally "
                         "famous D. Lacy. We guarantee it "
                         "will never run out of ink."
    },
    {
        "product_name": "ASAPP Stickers",
        "product_qty": 200,
        "product_descr": "Be the envy of your colleagues with these "
                         "amazing stickers."
    },
    {
        "product_name": "ASAPP Water Bottle",
        "product_qty": 25,
        "product_descr": "Ever been thirsty at work? No more, our new "
                         "state of the art bottles will keep you "
                         "hydrated 24/7. Water not included."
    }
]
